import React, { useState, useEffect, useMemo, useRef } from "react";
import { initializeApp, getApps, getApp } from "firebase/app";
import NTLogoImg from "./assets/NEWNT.png";
import {
  getFirestore,
  collection,
  addDoc,
  onSnapshot,
  deleteDoc,
  doc,
  updateDoc,
} from "firebase/firestore";
import {
  getAuth,
  signInAnonymously,
  onAuthStateChanged,
  signInWithCustomToken,
} from "firebase/auth";
import {
  History,
  Activity,
  Zap,
  Battery,
  PlusCircle,
  Trash2,
  Moon,
  Sun,
  Edit3,
  X,
  RefreshCw,
  CheckCircle2,
  Download,
  Camera,
  Layers,
  ChevronRight,
  ImageIcon,
  FileSpreadsheet,
} from "lucide-react";

// --- Firebase Configuration ---
const firebaseConfig =
  typeof __firebase_config !== "undefined"
    ? JSON.parse(__firebase_config)
    : {
        apiKey: "AIzaSyBAnqjbMtG7tWFbCKpaY-UQpwCqHt3hIGo",
        authDomain: "ntlogs-89f22.firebaseapp.com",
        projectId: "ntlogs-89f22",
        storageBucket: "ntlogs-89f22.firebasestorage.app",
        appId: "1:549427490184:web:ae23e7853b25a9d0d5de3d",
      };

const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
const db = getFirestore(app);
const auth = getAuth(app);
const appId =
  typeof __app_id !== "undefined" ? __app_id : "nt-server-monitor-v2";

// --- COMPONENT: EnergyInput ---
const EnergyInput = ({
  label,
  icon: Icon,
  valA,
  valB,
  setA,
  setB,
  colorClass,
  darkMode,
}) => {
  return (
    <div
      className={`relative p-6 rounded-[2.5rem] border-2 transition-all duration-300 ${
        darkMode
          ? "bg-slate-900 border-slate-800"
          : "bg-white border-slate-100 shadow-xl shadow-slate-200/50"
      }`}
    >
      <div className="flex items-center gap-3 mb-5">
        <div
          className={`p-2.5 rounded-xl bg-gradient-to-br ${colorClass} text-white shadow-lg`}
        >
          <Icon size={18} />
        </div>
        <span className="text-[10px] font-black uppercase tracking-widest opacity-60 leading-none">
          {label}
        </span>
      </div>

      <div className="flex items-center gap-3">
        <div className="flex-1">
          <label className="block text-[9px] font-black uppercase tracking-tighter opacity-40 ml-1 mb-1.5">
            System A
          </label>
          <input
            type="text"
            inputMode="decimal"
            value={valA}
            onChange={(e) => setA(e.target.value)}
            placeholder="0.0"
            className={`w-full h-14 rounded-2xl text-center font-black text-xl outline-none border-2 transition-all ${
              darkMode
                ? "bg-slate-800 border-slate-700 text-white focus:border-blue-500"
                : "bg-slate-50 border-transparent text-slate-900 focus:bg-white focus:border-blue-500"
            }`}
          />
        </div>
        <div className="pt-6 font-black opacity-10 text-lg">/</div>
        <div className="flex-1">
          <label className="block text-[9px] font-black uppercase tracking-tighter opacity-40 ml-1 mb-1.5">
            System B
          </label>
          <input
            type="text"
            inputMode="decimal"
            value={valB}
            onChange={(e) => setB(e.target.value)}
            placeholder="0.0"
            className={`w-full h-14 rounded-2xl text-center font-black text-xl outline-none border-2 transition-all ${
              darkMode
                ? "bg-slate-800 border-slate-700 text-white focus:border-indigo-500"
                : "bg-slate-50 border-transparent text-slate-900 focus:bg-white focus:border-indigo-500"
            }`}
          />
        </div>
      </div>
    </div>
  );
};

const App = () => {
  const [user, setUser] = useState(null);
  const [activeTab, setActiveTab] = useState("form");
  const [logs, setLogs] = useState([]);
  const [darkMode, setDarkMode] = useState(false);
  const [loading, setLoading] = useState(false);
  const [selectedLog, setSelectedLog] = useState(null);
  const [message, setMessage] = useState(null);

  // Form States
  const [liA, setLiA] = useState("");
  const [liB, setLiB] = useState("");
  const [stdA, setStdA] = useState("");
  const [stdB, setStdB] = useState("");
  const [upsA, setUpsA] = useState("");
  const [upsB, setUpsB] = useState("");

  const [inspector, setInspector] = useState("");
  const [images, setImages] = useState([]);
  const [editId, setEditId] = useState(null);
  const fileInputRef = useRef(null);

  const inspectors = [
    "ธนาพงศ์ บุญปัญญา",
    "ศุภวัฒน์ สววรณฤกษ์",
    "ณัฐพงศ์ ดำรงเวช",
    "ธนวัฒน์ สกุลหอม",
    "จิรศักดิ์ การญบริรักษ์",
    "ปยุต เอ้งฉ้วน",
    "ศุภชัย บ้านม่วง",
    "กิติภพ โรจนจินดา",
    "ปริญวัฒน์ ภาณุธนันทร์พงษ์",
  ];

  const checkItems = [
    "Server Room",
    "ความชื้นสัมพัทธ์",
    "ระบบปรับอากาศ",
    "พัดลม 4 ตัว",
    "ถังแก๊สดับเพลิง FM-200",
    "เสียงผิดปกติจากเซิร์ฟเวอร์",
    "ไฟแสดงสถานะอุปกรณ์",
    "Rectifier (lithium) 1000 Ah",
    "Rectifier 2000 Ah",
    "Power Room",
    "Battery Monitoring",
    "ระบบไฟฟ้า AC system A, system B (UPS)",
    "ไม่มีฝุ่น/สิ่งกีดขวาง",
    "กล้องวงจรปิด",
    "Access Control",
    "ไม่มีบุคคลภายนอก",
  ];

  const [checklist, setChecklist] = useState(
    checkItems.map((name) => ({ name, status: true, note: "ปกติ" }))
  );

  useEffect(() => {
    const initAuth = async () => {
      if (typeof __initial_auth_token !== "undefined" && __initial_auth_token) {
        await signInWithCustomToken(auth, __initial_auth_token);
      } else {
        await signInAnonymously(auth);
      }
    };
    initAuth();
    const unsub = onAuthStateChanged(auth, setUser);
    return () => unsub();
  }, []);

  useEffect(() => {
    if (!user) return;
    const colPath = `artifacts/${appId}/public/data/monitoring_logs`;
    const unsubscribe = onSnapshot(
      collection(db, colPath),
      (snap) => {
        const data = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
        // จัดเรียงแบบ Newest First สำหรับการแสดงผลในหน้า History UI
        setLogs(data.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0)));
      },
      (err) => console.error(err)
    );
    return () => unsubscribe();
  }, [user, appId]);

  const stats = useMemo(() => {
    const normalCount = logs.filter((l) => l.isNormal).length;
    return {
      total: logs.length,
      normal: normalCount,
      abnormal: logs.length - normalCount,
      days: new Set(logs.map((l) => l.dateStr)).size,
    };
  }, [logs]);

  const showMsg = (text, type = "success") => {
    setMessage({ text, type });
    setTimeout(() => setMessage(null), 3000);
  };

  const handleImageUpload = (e) => {
    const files = Array.from(e.target.files);
    files.forEach((file) => {
      const reader = new FileReader();
      reader.onloadend = () => setImages((prev) => [...prev, reader.result]);
      reader.readAsDataURL(file);
    });
  };

  const removeImage = (index) => {
    setImages(images.filter((_, i) => i !== index));
  };

  const handleSubmit = async () => {
    if (!inspector) {
      showMsg("กรุณาเลือกผู้ตรวจสอบ", "error");
      return;
    }
    setLoading(true);
    const now = new Date();
    const data = {
      inspector,
      liA: liA || "0",
      liB: liB || "0",
      stdA: stdA || "0",
      stdB: stdB || "0",
      upsA: upsA || "0",
      upsB: upsB || "0",
      checklist,
      images,
      timestamp: Date.now(),
      dateStr: now.toLocaleDateString("th-TH"),
      timeStr: now.toLocaleTimeString("th-TH", {
        hour: "2-digit",
        minute: "2-digit",
      }),
      isNormal: checklist.every((i) => i.status),
    };

    try {
      const colPath = `artifacts/${appId}/public/data/monitoring_logs`;
      if (editId) {
        await updateDoc(doc(db, colPath, editId), data);
        showMsg("อัปเดตข้อมูลสำเร็จ");
      } else {
        await addDoc(collection(db, colPath), data);
        showMsg("บันทึกข้อมูลสำเร็จ");
      }
      resetForm();
      setActiveTab("history");
    } catch (e) {
      showMsg("ผิดพลาด: " + e.message, "error");
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setEditId(null);
    setInspector("");
    setLiA("");
    setLiB("");
    setStdA("");
    setStdB("");
    setUpsA("");
    setUpsB("");
    setImages([]);
    setChecklist(
      checkItems.map((name) => ({ name, status: true, note: "ปกติ" }))
    );
  };

  const handleExport = async (targetLog = null) => {
    const isExportAll = !targetLog;
    showMsg(
      isExportAll
        ? "กำลังเตรียมไฟล์ Excel (รวมทั้งหมด เรียงจากก่อนไปหลัง)..."
        : "กำลังเตรียมไฟล์ Excel...",
      "info"
    );

    const script = document.createElement("script");
    script.src =
      "https://cdnjs.cloudflare.com/ajax/libs/exceljs/4.4.0/exceljs.min.js";
    script.onload = async () => {
      const ExcelJS = window.ExcelJS;
      const workbook = new ExcelJS.Workbook();

      // ถ้า Export All ให้เรียงจาก "ก่อนไปหลัง" (Oldest to Newest)
      let logsToExport = targetLog
        ? [targetLog]
        : [...logs].sort((a, b) => (a.timestamp || 0) - (b.timestamp || 0));

      if (logsToExport.length === 0) {
        showMsg("ไม่มีข้อมูลสำหรับ Export", "error");
        return;
      }

      for (const [idx, log] of logsToExport.entries()) {
        // สร้างชื่อ Sheet (ชื่อไฟล์ + เวลา)
        let sheetName = (log.dateStr + "_" + log.timeStr)
          .replace(/[\/:]/g, "-")
          .substring(0, 25);

        // ถ้าเป็น Export All เติมลำดับข้างหน้าเพื่อให้ชื่อ Sheet ไม่ซ้ำและเรียงสวยงาม
        if (isExportAll) sheetName = `${idx + 1}_${sheetName}`;

        const worksheet = workbook.addWorksheet(sheetName);
        worksheet.columns = [
          { header: "รายการ", key: "label", width: 25 },
          { header: "ข้อมูล", key: "value", width: 40 },
        ];

        worksheet.getRow(1).font = { bold: true };

        worksheet.addRow(["👤 ผู้ตรวจสอบ", log.inspector]);
        worksheet.addRow(["📅 วันที่ตรวจสอบ", log.dateStr]);
        worksheet.addRow(["🕒 เวลาบันทึก", log.timeStr]);
        worksheet.addRow([
          "📝 สถานะรวม",
          log.isNormal ? "ปกติ" : "พบความผิดปกติ",
        ]);
        worksheet.addRow(["🔋 Rect (Li) A/B", `${log.liA} / ${log.liB}`]);
        worksheet.addRow(["🔋 Rect (Std) A/B", `${log.stdA} / ${log.stdB}`]);
        worksheet.addRow(["⚡ UPS A/B (kW)", `${log.upsA} / ${log.upsB}`]);
        worksheet.addRow([]);

        const checkHeader = worksheet.addRow([
          "ลำดับ",
          "รายการตรวจสอบ",
          "สถานะ",
          "หมายเหตุ",
        ]);
        checkHeader.font = { bold: true };

        log.checklist.forEach((item, cidx) =>
          worksheet.addRow([
            cidx + 1,
            item.name,
            item.status ? "✔" : "✘",
            item.note,
          ])
        );

        if (log.images && log.images.length > 0) {
          worksheet.addRow([]);
          worksheet.addRow(["📸 รูปภาพแนบประกอบ"]);
          let currentRow = worksheet.lastRow.number + 1;
          for (const [imgIdx, base64] of log.images.entries()) {
            try {
              const imageId = workbook.addImage({ base64, extension: "png" });
              worksheet.addImage(imageId, {
                tl: { col: 0, row: currentRow + imgIdx * 15 },
                ext: { width: 300, height: 200 },
              });
            } catch (err) {
              console.error("Error adding image to excel", err);
            }
          }
        }
      }

      const buffer = await workbook.xlsx.writeBuffer();
      const blob = new Blob([buffer], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      });
      const url = window.URL.createObjectURL(blob);
      const anchor = document.createElement("a");
      anchor.href = url;
      anchor.download = isExportAll
        ? `NT_Full_Report_OldestFirst_${
            new Date().toISOString().split("T")[0]
          }.xlsx`
        : `NT_Report_${targetLog.dateStr.replace(/\//g, "-")}.xlsx`;
      anchor.click();
      window.URL.revokeObjectURL(url);
      showMsg("Export สำเร็จ!");
    };
    document.head.appendChild(script);
  };

  const handleEdit = (log, e) => {
    e.stopPropagation();
    setEditId(log.id);
    setInspector(log.inspector);
    setLiA(log.liA);
    setLiB(log.liB);
    setStdA(log.stdA);
    setStdB(log.stdB);
    setUpsA(log.upsA);
    setUpsB(log.upsB);
    setChecklist(log.checklist);
    setImages(log.images || []);
    setActiveTab("form");
  };

  return (
    <div
      className={`min-h-screen pb-32 transition-colors duration-500 ${
        darkMode ? "bg-slate-950 text-white" : "bg-slate-50 text-slate-900"
      }`}
    >
      {/* Header */}
      <header
        className={`sticky top-0 z-40 px-6 py-5 backdrop-blur-xl border-b ${
          darkMode
            ? "bg-slate-950/80 border-slate-800"
            : "bg-white/80 border-slate-200"
        }`}
      >
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white-600 rounded-xl text-white">
              <img src={NTLogoImg} alt="NT Logo.png" className="w-16 h-auto" />
            </div>
            <div>
              <h1 className="font-black text-xl leading-none">NT MONITORING</h1>
              <p className="text-[9px] font-black text-blue-500 mt-1.5 uppercase tracking-widest opacity-80">
                Floor 12 • Operations
              </p>
            </div>
          </div>
          <button
            onClick={() => setDarkMode(!darkMode)}
            className={`p-3.5 rounded-2xl shadow-lg ${
              darkMode
                ? "bg-slate-800 text-yellow-400"
                : "bg-white text-slate-600 shadow-slate-200"
            }`}
          >
            {darkMode ? <Sun size={20} /> : <Moon size={20} />}
          </button>
        </div>
      </header>

      <main className="max-w-4xl mx-auto p-5 space-y-8 mt-4">
        {activeTab === "form" ? (
          <div className="space-y-8 animate-in fade-in duration-500">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <EnergyInput
                label="Rect (Li) 1000 Ah"
                icon={Battery}
                valA={liA}
                valB={liB}
                setA={setLiA}
                setB={setLiB}
                colorClass="from-blue-500 to-cyan-400"
                darkMode={darkMode}
              />
              <EnergyInput
                label="Rect (Std) 2000 Ah"
                icon={Zap}
                valA={stdA}
                valB={stdB}
                setA={setStdA}
                setB={setStdB}
                colorClass="from-indigo-600 to-blue-500"
                darkMode={darkMode}
              />
              <EnergyInput
                label="UPS Load (kW)"
                icon={Activity}
                valA={upsA}
                valB={upsB}
                setA={setUpsA}
                setB={setUpsB}
                colorClass="from-emerald-500 to-teal-400"
                darkMode={darkMode}
              />
            </div>

            <div
              className={`rounded-[3rem] border-2 overflow-hidden transition-all ${
                darkMode
                  ? "bg-slate-900 border-slate-800"
                  : "bg-white border-slate-100 shadow-2xl shadow-slate-200/40"
              }`}
            >
              <div className="p-8 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="p-3 bg-emerald-500/10 text-emerald-500 rounded-2xl">
                    <CheckCircle2 size={22} />
                  </div>
                  <h3 className="text-sm font-black uppercase tracking-widest">
                    Inspection Checklist
                  </h3>
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2">
                {checklist.map((item, idx) => (
                  <div
                    key={idx}
                    className={`flex items-center gap-5 p-6 border-b transition-all ${
                      darkMode
                        ? "border-slate-800 hover:bg-slate-800/30"
                        : "border-slate-50 hover:bg-slate-50/50"
                    }`}
                  >
                    <button
                      onClick={() => {
                        const c = [...checklist];
                        c[idx].status = !c[idx].status;
                        c[idx].note = c[idx].status ? "ปกติ" : "";
                        setChecklist(c);
                      }}
                      className={`shrink-0 w-14 h-14 rounded-2xl flex items-center justify-center transition-all shadow-lg active:scale-90 ${
                        item.status
                          ? "bg-gradient-to-br from-emerald-500 to-teal-400 text-white"
                          : "bg-gradient-to-br from-red-500 to-rose-400 text-white"
                      }`}
                    >
                      {item.status ? (
                        <CheckCircle2 size={28} />
                      ) : (
                        <X size={28} />
                      )}
                    </button>
                    <div className="flex-1 min-w-0">
                      <p className="text-[13px] font-black truncate mb-1.5">
                        {item.name}
                      </p>
                      <input
                        value={item.note}
                        onChange={(e) => {
                          const c = [...checklist];
                          c[idx].note = e.target.value;
                          setChecklist(c);
                        }}
                        className={`w-full bg-transparent text-[11px] font-bold outline-none border-b ${
                          darkMode
                            ? "border-slate-700 text-slate-400 focus:border-blue-500"
                            : "border-slate-200 text-slate-500 focus:border-blue-500"
                        }`}
                        placeholder="ระบุรายละเอียด..."
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div
                className={`p-8 rounded-[3rem] border-2 ${
                  darkMode
                    ? "bg-slate-900 border-slate-800"
                    : "bg-white border-slate-100 shadow-2xl shadow-slate-200/40"
                }`}
              >
                <div className="flex items-center justify-between mb-8">
                  <div className="flex items-center gap-4">
                    <div className="p-3 bg-blue-500/10 text-blue-500 rounded-2xl">
                      <Camera size={20} />
                    </div>
                    <h3 className="text-sm font-black uppercase tracking-widest">
                      Photos
                    </h3>
                  </div>
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="px-6 py-3 bg-blue-600 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-xl shadow-blue-500/30"
                  >
                    Upload
                  </button>
                  <input
                    type="file"
                    ref={fileInputRef}
                    multiple
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                  />
                </div>
                <div className="grid grid-cols-4 gap-4">
                  {images.map((img, i) => (
                    <div
                      key={i}
                      className="relative aspect-square rounded-2xl overflow-hidden border-2 border-slate-200 dark:border-slate-700 group"
                    >
                      <img
                        src={img}
                        alt="p"
                        className="w-full h-full object-cover"
                      />
                      <button
                        onClick={() => removeImage(i)}
                        className="absolute inset-0 bg-red-500/80 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all"
                      >
                        <Trash2 size={20} />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              <div
                className={`p-8 rounded-[3rem] border-2 ${
                  darkMode
                    ? "bg-slate-900 border-slate-800"
                    : "bg-white border-slate-100 shadow-2xl shadow-slate-200/40"
                }`}
              >
                <label className="text-[11px] font-black uppercase tracking-widest opacity-40 ml-2 mb-4 block">
                  Inspector Name
                </label>
                <select
                  value={inspector}
                  onChange={(e) => setInspector(e.target.value)}
                  className={`w-full p-6 rounded-3xl text-sm font-black outline-none border-2 mb-6 ${
                    darkMode
                      ? "bg-slate-800 border-slate-700"
                      : "bg-slate-50 border-transparent focus:bg-white focus:border-blue-500"
                  }`}
                >
                  <option value="">Choose Inspector...</option>
                  {inspectors.map((n) => (
                    <option key={n} value={n}>
                      {n}
                    </option>
                  ))}
                </select>
                <button
                  disabled={loading}
                  onClick={handleSubmit}
                  className={`w-full py-6 rounded-3xl font-black text-xs uppercase tracking-[0.3em] transition-all flex items-center justify-center gap-4 ${
                    inspector
                      ? "bg-blue-600 text-white shadow-2xl shadow-blue-500/40"
                      : "bg-slate-200 text-slate-400"
                  }`}
                >
                  {loading ? (
                    <RefreshCw className="animate-spin" size={20} />
                  ) : (
                    "Save Record"
                  )}
                </button>
              </div>
            </div>
          </div>
        ) : (
          <div className="space-y-6 animate-in fade-in duration-500">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <h2 className="text-xl font-black uppercase tracking-tighter">
                History Logs
              </h2>
              {logs.length > 0 && (
                <button
                  onClick={() => handleExport()}
                  className="flex items-center justify-center gap-2 px-6 py-3 bg-emerald-600 text-white rounded-2xl text-[11px] font-black uppercase tracking-widest shadow-xl shadow-emerald-500/30 hover:bg-emerald-700 transition-all"
                >
                  <FileSpreadsheet size={16} />
                  Export All (Oldest First)
                </button>
              )}
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                { label: "Total", val: stats.total, color: "text-blue-500" },
                {
                  label: "Normal",
                  val: stats.normal,
                  color: "text-emerald-500",
                },
                {
                  label: "Abnormal",
                  val: stats.abnormal,
                  color: "text-red-500",
                },
                { label: "Days", val: stats.days, color: "text-indigo-500" },
              ].map((s, i) => (
                <div
                  key={i}
                  className={`p-6 rounded-[2rem] border-2 ${
                    darkMode
                      ? "bg-slate-900 border-slate-800"
                      : "bg-white border-slate-100 shadow-xl shadow-slate-200/20"
                  }`}
                >
                  <p className={`text-3xl font-black ${s.color}`}>{s.val}</p>
                  <p className="text-[9px] font-black uppercase opacity-40 tracking-widest mt-1">
                    {s.label}
                  </p>
                </div>
              ))}
            </div>

            <div className="space-y-4">
              {logs.map((log) => {
                const normalItems = log.checklist.filter(
                  (i) => i.status
                ).length;
                const totalItems = log.checklist.length;
                const hasImages = log.images && log.images.length > 0;

                return (
                  <div
                    key={log.id}
                    onClick={() => setSelectedLog(log)}
                    className={`group relative p-6 rounded-[2.5rem] border-2 cursor-pointer transition-all hover:translate-y-[-2px] ${
                      darkMode
                        ? "bg-slate-900 border-slate-800 hover:border-blue-500/50"
                        : "bg-white border-slate-100 shadow-xl shadow-slate-200/30 hover:border-blue-200"
                    }`}
                  >
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                      <div className="flex items-center gap-5">
                        <div
                          className={`w-14 h-14 rounded-2xl flex flex-col items-center justify-center font-black ${
                            log.isNormal
                              ? "bg-emerald-500 text-white"
                              : "bg-red-500 text-white"
                          }`}
                        >
                          <span className="text-[14px] leading-none">
                            {log.isNormal ? "OK" : "ERR"}
                          </span>
                          <span className="text-[8px] opacity-80 mt-1">
                            {normalItems}/{totalItems}
                          </span>
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <h3 className="font-black text-[15px]">
                              {log.inspector}
                            </h3>
                            {hasImages && (
                              <ImageIcon size={14} className="text-blue-500" />
                            )}
                          </div>
                          <p className="text-[10px] font-bold opacity-40 uppercase tracking-wider">
                            {log.dateStr} • {log.timeStr}
                          </p>
                        </div>
                      </div>

                      <div className="flex-1 grid grid-cols-3 gap-3 md:max-w-md">
                        <div
                          className={`p-3 rounded-2xl border ${
                            darkMode
                              ? "bg-slate-800/50 border-slate-700"
                              : "bg-slate-50 border-slate-100"
                          }`}
                        >
                          <p className="text-[8px] font-black uppercase opacity-40 mb-1">
                            Rect (Li)
                          </p>
                          <p className="text-[11px] font-black text-blue-500">
                            {log.liA} / {log.liB}
                          </p>
                        </div>
                        <div
                          className={`p-3 rounded-2xl border ${
                            darkMode
                              ? "bg-slate-800/50 border-slate-700"
                              : "bg-slate-50 border-slate-100"
                          }`}
                        >
                          <p className="text-[8px] font-black uppercase opacity-40 mb-1">
                            Rect (Std)
                          </p>
                          <p className="text-[11px] font-black text-indigo-500">
                            {log.stdA} / {log.stdB}
                          </p>
                        </div>
                        <div
                          className={`p-3 rounded-2xl border ${
                            darkMode
                              ? "bg-slate-800/50 border-slate-700"
                              : "bg-slate-50 border-slate-100"
                          }`}
                        >
                          <p className="text-[8px] font-black uppercase opacity-40 mb-1">
                            UPS (kW)
                          </p>
                          <p className="text-[11px] font-black text-emerald-500">
                            {log.upsA} / {log.upsB}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 self-end md:self-center">
                        <button
                          onClick={(e) => handleEdit(log, e)}
                          className="p-3.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-500 hover:bg-blue-600 hover:text-white transition-colors"
                        >
                          <Edit3 size={16} />
                        </button>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            if (confirm("ต้องการลบข้อมูลนี้หรือไม่?"))
                              deleteDoc(
                                doc(
                                  db,
                                  `artifacts/${appId}/public/data/monitoring_logs`,
                                  log.id
                                )
                              );
                          }}
                          className="p-3.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-500 hover:bg-red-600 hover:text-white transition-colors"
                        >
                          <Trash2 size={16} />
                        </button>
                        <div className="p-3.5 rounded-xl bg-blue-600/10 text-blue-600 group-hover:bg-blue-600 group-hover:text-white transition-all">
                          <ChevronRight size={16} />
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
              {logs.length === 0 && (
                <div className="py-20 text-center opacity-20">
                  <History size={64} className="mx-auto mb-4" />
                  <p className="font-black uppercase tracking-widest text-xs">
                    No records found
                  </p>
                </div>
              )}
            </div>
          </div>
        )}
      </main>

      {/* Detail Modal */}
      {selectedLog && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-xl animate-in fade-in duration-300">
          <div
            className={`w-full max-w-3xl max-h-[90vh] overflow-y-auto rounded-[3.5rem] p-8 md:p-12 border-4 shadow-2xl ${
              darkMode
                ? "bg-slate-900 border-slate-800"
                : "bg-white border-white"
            }`}
          >
            <div className="flex justify-between items-start mb-10">
              <div>
                <h3 className="text-2xl font-black mb-2">
                  {selectedLog.inspector}
                </h3>
                <p className="text-xs font-bold opacity-40 uppercase tracking-widest">
                  {selectedLog.dateStr} • {selectedLog.timeStr}
                </p>
              </div>
              <button
                onClick={() => setSelectedLog(null)}
                className="p-4 rounded-3xl bg-slate-100 dark:bg-slate-800 hover:bg-red-500 hover:text-white transition-all active:scale-90"
              >
                <X size={24} />
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
              <div className="p-6 rounded-[2rem] bg-blue-500/10 border-2 border-blue-500/20">
                <div className="flex items-center gap-3 mb-4 text-blue-500">
                  <Battery size={20} />
                  <span className="text-[10px] font-black uppercase tracking-widest">
                    Rect (Li)
                  </span>
                </div>
                <p className="text-2xl font-black">
                  {selectedLog.liA} / {selectedLog.liB}
                </p>
              </div>
              <div className="p-6 rounded-[2rem] bg-indigo-500/10 border-2 border-indigo-500/20">
                <div className="flex items-center gap-3 mb-4 text-indigo-500">
                  <Zap size={20} />
                  <span className="text-[10px] font-black uppercase tracking-widest">
                    Rect (Std)
                  </span>
                </div>
                <p className="text-2xl font-black">
                  {selectedLog.stdA} / {selectedLog.stdB}
                </p>
              </div>
              <div className="p-6 rounded-[2rem] bg-emerald-500/10 border-2 border-emerald-500/20">
                <div className="flex items-center gap-3 mb-4 text-emerald-500">
                  <Activity size={20} />
                  <span className="text-[10px] font-black uppercase tracking-widest">
                    UPS Load
                  </span>
                </div>
                <p className="text-2xl font-black">
                  {selectedLog.upsA} / {selectedLog.upsB}{" "}
                  <span className="text-xs opacity-40 ml-1">kW</span>
                </p>
              </div>
            </div>

            <div className="space-y-3 mb-10">
              <h4 className="text-[11px] font-black uppercase tracking-widest opacity-40 ml-2 mb-4">
                Checklist Details
              </h4>
              {selectedLog.checklist.map((item, idx) => (
                <div
                  key={idx}
                  className={`flex items-center justify-between p-5 rounded-3xl border-2 ${
                    darkMode
                      ? "bg-slate-800/30 border-slate-800"
                      : "bg-slate-50 border-slate-100"
                  }`}
                >
                  <div className="flex items-center gap-4">
                    {item.status ? (
                      <CheckCircle2 size={20} className="text-emerald-500" />
                    ) : (
                      <X size={20} className="text-red-500" />
                    )}
                    <span className="text-sm font-bold">{item.name}</span>
                  </div>
                  <span
                    className={`text-[10px] font-black uppercase px-4 py-1.5 rounded-full ${
                      item.status
                        ? "bg-emerald-500/10 text-emerald-500"
                        : "bg-red-500/10 text-red-500"
                    }`}
                  >
                    {item.note || (item.status ? "ปกติ" : "พบปัญหา")}
                  </span>
                </div>
              ))}
            </div>

            {selectedLog.images && selectedLog.images.length > 0 && (
              <div className="mb-10">
                <h4 className="text-[11px] font-black uppercase tracking-widest opacity-40 ml-2 mb-4">
                  Attached Photos
                </h4>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {selectedLog.images.map((img, i) => (
                    <div
                      key={i}
                      className="aspect-square rounded-[2rem] overflow-hidden border-2 border-slate-200 dark:border-slate-700 shadow-lg"
                    >
                      <img
                        src={img}
                        alt="captured"
                        className="w-full h-full object-cover"
                      />
                    </div>
                  ))}
                </div>
              </div>
            )}

            <button
              onClick={() => handleExport(selectedLog)}
              className="w-full py-6 rounded-3xl bg-blue-600 text-white font-black text-xs uppercase tracking-[0.3em] flex items-center justify-center gap-4 shadow-2xl shadow-blue-500/40 active:scale-[0.98] transition-all"
            >
              <Download size={20} /> Export Detailed Excel
            </button>
          </div>
        </div>
      )}

      {message && (
        <div
          className={`fixed top-24 left-1/2 -translate-x-1/2 z-[200] px-8 py-4 rounded-3xl font-black text-xs uppercase tracking-widest shadow-2xl animate-in slide-in-from-top duration-300 ${
            message.type === "error"
              ? "bg-red-500 text-white shadow-red-500/40"
              : message.type === "info"
              ? "bg-blue-500 text-white shadow-blue-500/40"
              : "bg-emerald-500 text-white shadow-emerald-500/40"
          }`}
        >
          {message.text}
        </div>
      )}

      <nav className="fixed bottom-10 left-1/2 -translate-x-1/2 z-50 w-full max-w-xs">
        <div
          className={`p-3 rounded-[3rem] flex shadow-2xl border-2 backdrop-blur-xl ${
            darkMode
              ? "bg-slate-950/80 border-slate-800"
              : "bg-white/90 border-slate-100"
          }`}
        >
          {[
            { id: "form", icon: PlusCircle, label: "Add Record" },
            { id: "history", icon: History, label: "History Logs" },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex-1 flex flex-col items-center py-4 rounded-[2.5rem] transition-all ${
                activeTab === tab.id
                  ? "bg-blue-600 text-white shadow-lg scale-105"
                  : "text-slate-400 opacity-60 hover:opacity-100"
              }`}
            >
              <tab.icon size={20} />
              <span className="text-[8px] font-black mt-2 uppercase tracking-widest">
                {tab.label}
              </span>
            </button>
          ))}
        </div>
      </nav>

      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap');
        * { font-family: 'Plus Jakarta Sans', sans-serif; -webkit-tap-highlight-color: transparent; }
        .animate-in { animation: fadeIn 0.3s ease-out; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
      `}</style>
    </div>
  );
};

export default App;
